# PocketLab Voyager 2 – Offline-QR (nur Deutsch)

Die Version enthält alle Messfunktionen von v0.9.5, aber **nur die deutschen Beschriftungen und Hilfetexte**. Auch auf einem englisch eingestellten Smartphone werden die deutschen Texte verwendet. Für Deutsch/Englisch bleibt die ursprüngliche v0.9.5 verfügbar.

## So geht der Offline-Import

1. Das Paket auf dem PC entpacken.
2. `QR_Anzeige_Start.html` im Browser öffnen (ohne Internet möglich).
3. In phyphox auf dem Smartphone den Experiment-QR-Scanner öffnen.
4. Die **7 QR-Codes** nacheinander scannen; in der HTML-Datei jeweils auf **Weiter** klicken.
5. Nach dem letzten Scan das Experiment importieren.
6. Voyager 2 einschalten, Bluetooth aktivieren und eine kurze Messung mit Beschleunigung und Winkelgeschwindigkeit durchführen.
7. Messung über die phyphox-Exportfunktion als CSV speichern.

Alternativ lässt sich die Datei `Voyager2_Sensorwahl_v095_Nur_Deutsch.phyphox` direkt in phyphox importieren.

Die Bluetooth-Kommandos, Sensorwahl, Datenverarbeitung, Zeitachse und CSV-Struktur wurden **nicht verändert**. Das QR-Paket wurde technisch dekodiert und mit der deutschen Originaldatei bytegenau verglichen. Der Test mit phyphox auf Android steht noch aus.
