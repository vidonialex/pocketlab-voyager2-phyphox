# Voyager 2 v0.9.7 – Releasekandidat, Deutsch

Noch unveröffentlicht. Der bisherige Kandidat bestand am 21.11.2026 beide Direktimporte, Messung/START/STOPP/Wiederverbindung/CSV und den Import aller zwölf Offline-Codes mit Funktionstest. Danach wurden ausschließlich Starttexte korrigiert; diese aktualisierte Datei und die neu erzeugten 13 Codes benötigen einen erneuten Android-Importtest.

Entpacken, QR_Anzeige_Start.html öffnen und alle 13 Codes im phyphox-QR-Scanner nacheinander scannen. Die Codes enthalten das vollständige komprimierte Experiment; beim Scannen ist kein Internet erforderlich. Alternativ Voyager2_v097_DE.phyphox direkt importieren. Die enthaltene .phyphox.zip ist der binäre QR-Inhalt, kein zusätzlicher notwendiger Bedienungsschritt.

Bei jedem Messstart und Wiederaufnehmen empfohlen: Bluetooth verbinden → Sensoren auswählen → ▶ oben rechts → Messdaten STARTEN. STARTEN vor ▶ funktionierte beim erstmaligen Messstart, nach Pause und Wiederaufnahme jedoch nicht zuverlässig. Ursache nicht abschließend geklärt; kein Nachweis allgemeinen phyphox-Verhaltens. Sensorwechsel: STOPPEN → Auswahl → STARTEN. Beenden: STOPPEN → phyphox pausieren. Export: ⋮ → Daten exportieren → CSV → speichern/teilen.

10 Messgrößen, 16 Kanäle, 26 CSV-Spalten. IR in m, feste Anzeige 0–6 m; Rohwerte außerhalb bleiben im CSV. NaN bedeutet Not a Number, nicht null; eigene Zeitspalten beachten. Keine unabhängige Kalibrierung; angenäherte Zeitbasis; keine systematischen Langzeit-, CPU- oder Speicherprüfungen.

Offline-Inhalt: 15961 Bytes; 13 Segmente mit maximal 1328 Nutzbytes. CRC32 des vollständigen ZIPs: 107107ba. Segmentindizes sind intern nullbasiert. Experiment-SHA256: 5433833a78dd2b9d376d8a52341c6a413f422d12081e84982e005405543ca650.
