# PocketLab Voyager 2 – Offline-QR-Import v0.9.6 (Deutsch)

Dieses Paket enthält die deutsche phyphox-Experimentdatei mit neun auswählbaren Messgrößen einschließlich der externen Temperatursonde.

## Import

1. ZIP-Paket auf einem Computer entpacken und `QR_Anzeige_Start.html` in einem Browser öffnen.
2. In phyphox auf Android im Hauptmenü den QR-Scanner für Experimente öffnen.
3. Alle **8 QR-Codes** in der angegebenen Reihenfolge scannen; in der HTML-Anzeige jeweils **Weiter** wählen.
4. Experiment öffnen und den PocketLab Voyager 2 per Bluetooth verbinden.
5. Messwerte unter **Sensorauswahl** auswählen und eine Messung durchführen.

Alternativ kann `Voyager2_v096_DE.phyphox` direkt in phyphox importiert werden.

**Bestätigte Android-Abschlussprüfungen vom 15.11.2026:** Die deutsche und die zweisprachige v0.9.6-Experimentdatei wurden erfolgreich importiert und visuell geprüft. Alle acht korrigierten Offline-QR-Codes wurden erfolgreich in phyphox importiert. Die externe Temperatursonde ist in der Sensorauswahl und den Info-/Hilfetexten vorhanden; eine Temperaturmessung mit der externen Sonde war erfolgreich. Die gleichzeitige Erfassung aller neun Messgrößen war bereits zuvor erfolgreich getestet.

**Einschränkungen:** Diese funktionalen Tests sind keine unabhängige Kalibrierung oder metrologische Validierung. Langzeitstabilität sowie Online-QR-Import und Live-Prüfung der v0.9.6-Webseite nach der Veröffentlichung stehen noch aus.
